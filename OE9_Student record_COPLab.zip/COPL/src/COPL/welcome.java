package COPL;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Window.Type;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.ImageIcon;

public class welcome extends JFrame {

	JFrame welcome;
	JPanel contentPane;
    JTextField txtUser;
    
    public static String NAME;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					welcome frame = new welcome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
/**
	 * Create the frame.
	 */
	public welcome() {
		setType(Type.POPUP);
		setTitle("Main");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 558, 311);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("W E L C O M E ,");
		lblNewLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 25));
		lblNewLabel.setBounds(39, 52, 201, 65);
		contentPane.add(lblNewLabel);
		
		JButton btnGoback = new JButton("GO BACK");
		btnGoback.setBackground(new Color(210, 180, 140));
		btnGoback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				login frmLogin = new login();
				frmLogin.setVisible(true);
				dispose();
				
			}
		});
		btnGoback.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnGoback.setBounds(201, 228, 95, 33);
		contentPane.add(btnGoback);
		
		JLabel lblNewLabel_2 = new JLabel("TO THE EXCITING PART");
		lblNewLabel_2.setFont(new Font("Segoe UI Black", Font.BOLD, 16));
		lblNewLabel_2.setBounds(151, 128, 201, 43);
		contentPane.add(lblNewLabel_2);
		
		txtUser = new JTextField();
		txtUser.setHorizontalAlignment(SwingConstants.CENTER);
		txtUser.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		txtUser.setBounds(237, 58, 150, 43);
		contentPane.add(txtUser);
		txtUser.setColumns(10);
		txtUser.setEditable(false);
		txtUser.setText(login.USERNAME);
		
		JButton btnrecord = new JButton("STUDENT RECORDS");
		btnrecord.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				studentrecords frmStudentrecords = new studentrecords();
				frmStudentrecords.setVisible(true);
				dispose();
				NAME =txtUser.getText().toString();
				frmStudentrecords.txtUser2.setText(NAME);
			}
		});
		btnrecord.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnrecord.setBackground(new Color(210, 180, 140));
		btnrecord.setBounds(161, 182, 178, 35);
		contentPane.add(btnrecord);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\lenovo\\Documents\\COPL\\img\\Picture8.png"));
		lblNewLabel_1.setBounds(-91, 0, 637, 322);
		contentPane.add(lblNewLabel_1);
	}
}
