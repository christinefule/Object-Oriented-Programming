package COPL;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Window.Type;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.ImageIcon;

public class welcome extends JFrame {

	JFrame welcome;
	JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					welcome frame = new welcome();
					frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

/**
	 * Create the frame.
	 */
	public welcome() {
		setType(Type.POPUP);
		setTitle("Main");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 558, 311);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("W E L C O M E   U S E R");
		lblNewLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 25));
		lblNewLabel.setBounds(95, 53, 337, 65);
		contentPane.add(lblNewLabel);
		
		JButton btnGoback = new JButton("GO BACK");
		btnGoback.setBackground(new Color(210, 180, 140));
		btnGoback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				login frmLogin = new login();
				frmLogin.setVisible(true);
				dispose();
			}
		});
		btnGoback.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnGoback.setBounds(201, 228, 95, 33);
		contentPane.add(btnGoback);
		
		JLabel lblNewLabel_2 = new JLabel("TO THE EXCITING PART");
		lblNewLabel_2.setFont(new Font("Segoe UI Black", Font.BOLD, 16));
		lblNewLabel_2.setBounds(151, 128, 201, 43);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\lenovo\\Documents\\img\\Picture8.png"));
		lblNewLabel_1.setBounds(-85, -18, 631, 313);
		contentPane.add(lblNewLabel_1);
	}
}
