package COPL;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Window.Type;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.sql.Connection;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import java.awt.SystemColor;

import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class studentrecords extends JFrame {

	private JPanel contentPane;
	private JTextField txtStudentNo;
	private JTextField txtStudentName;
	@SuppressWarnings("rawtypes")
	private JComboBox txtgender;
	private JTextField txtAddress;
	private JTextField txtYearlevel;
	private JTextField txtContactNo;
	JTextField txtUser2;
	private JTextField txtsearch;
	private JTable tableView;
	private JLabel lblClock;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					studentrecords frame = new studentrecords();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public studentrecords() {
		initialize();
		clock();
		viewRecords();
	}
	private void initialize() {
		
		setType(Type.POPUP);
		setTitle("STUDENTS PORTFOLIO");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1455, 775);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblstudentrecord = new JLabel("STUDENT RECORD SYSTEM");
		lblstudentrecord.setFont(new Font("Rockwell Extra Bold", Font.PLAIN, 26));
		lblstudentrecord.setBounds(29, 33, 420, 34);
		contentPane.add(lblstudentrecord);
		
		JLabel lblNewLabel = new JLabel("Student Portfolio");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(138, 69, 132, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblstudentnum = new JLabel("STUDENT NUMBER :");
		lblstudentnum.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblstudentnum.setBounds(27, 141, 132, 22);
		contentPane.add(lblstudentnum);
		
		JLabel lblstudentname = new JLabel("STUDENT NAME :");
		lblstudentname.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblstudentname.setBounds(27, 199, 132, 22);
		contentPane.add(lblstudentname);
		
		JLabel lbladdress = new JLabel("ADDRESS :");
		lbladdress.setFont(new Font("Tahoma", Font.BOLD, 12));
		lbladdress.setBounds(29, 314, 132, 22);
		contentPane.add(lbladdress);
		
		JLabel lblyrlvl = new JLabel("YEAR LEVEL :");
		lblyrlvl.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblyrlvl.setBounds(29, 372, 132, 22);
		contentPane.add(lblyrlvl);
		
		JLabel lblcontactnum = new JLabel("CONTACT NUMBER :");
		lblcontactnum.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblcontactnum.setBounds(29, 433, 132, 22);
		contentPane.add(lblcontactnum);
		
		txtStudentNo = new JTextField();
		txtStudentNo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtStudentNo.setBounds(150, 134, 139, 34);
		contentPane.add(txtStudentNo);
		txtStudentNo.setColumns(10);
		
		txtStudentName = new JTextField();
		txtStudentName.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtStudentName.setColumns(10);
		txtStudentName.setBounds(150, 192, 139, 34);
		contentPane.add(txtStudentName);
		
		txtAddress = new JTextField();
		txtAddress.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtAddress.setColumns(10);
		txtAddress.setBounds(150, 307, 139, 34);
		contentPane.add(txtAddress);
		
		txtYearlevel = new JTextField();
		txtYearlevel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtYearlevel.setColumns(10);
		txtYearlevel.setBounds(150, 365, 139, 34);
		contentPane.add(txtYearlevel);
		
		txtContactNo = new JTextField();
		txtContactNo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtContactNo.setColumns(10);
		txtContactNo.setBounds(150, 426, 139, 34);
		contentPane.add(txtContactNo);
		
		JButton btnclear = new JButton("CLEAR");
		btnclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearTextField();
			}
		});
		btnclear.setBackground(new Color(210, 180, 140));
		btnclear.setBounds(47, 513, 112, 34);
		contentPane.add(btnclear);
		
		JButton btngoback = new JButton("GO BACK");
		btngoback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login frmLogin = new login();
				frmLogin.setVisible(true);
				dispose();
			}
		});
		btngoback.setBackground(new Color(210, 180, 140));
		btngoback.setBounds(47, 558, 112, 34);
		contentPane.add(btngoback);
		
		JButton btnadd = new JButton("ADD");
		btnadd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addRecord();
			}
		});
		
		//database connection
			
		btnadd.setBackground(new Color(210, 180, 140));
		btnadd.setBounds(181, 513, 100, 34);
		contentPane.add(btnadd);
		
		JButton btnrefresh = new JButton("REFRESH");
		btnrefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				viewRecords();
			}
		});
		btnrefresh.setBackground(new Color(210, 180, 140));
		btnrefresh.setBounds(114, 659, 100, 34);
		contentPane.add(btnrefresh);
		
		JButton btndelete = new JButton("DELETE");
		btndelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			int Delete =JOptionPane.showConfirmDialog(null,"Do you really want to delete it?","Delete Table", JOptionPane.YES_NO_OPTION);
			
			if(Delete == JOptionPane.YES_OPTION) {
				System.exit(0);
			}
			else if(Delete == JOptionPane.NO_OPTION) {
			}
			if(tableView.getSelectedRow()>=0) {
				deleteRecord(txtStudentNo.getText());
			}
		
			}
		});
		btndelete.setBackground(new Color(210, 180, 140));
		btndelete.setBounds(181, 603, 100, 34);
		contentPane.add(btndelete);
		
		JButton btnexit = new JButton("EXIT");
		btnexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int Exit =JOptionPane.showConfirmDialog(null,"Do you really want to exit this program?","Exit Program", JOptionPane.YES_NO_OPTION);
				
				if(Exit == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
				else if(Exit == JOptionPane.NO_OPTION) {
				}
			}
		});
		btnexit.setBackground(new Color(210, 180, 140));
		btnexit.setBounds(47, 603, 112, 34);
		contentPane.add(btnexit);
		
		txtUser2 = new JTextField();
		txtUser2.setHorizontalAlignment(SwingConstants.CENTER);
		txtUser2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtUser2.setBounds(1218, 11, 202, 31);
		contentPane.add(txtUser2);
		txtUser2.setColumns(10);
		txtUser2.setEditable(false);
		txtUser2.setText(welcome.NAME);
		
		
		txtsearch = new JTextField();
		txtsearch.addKeyListener(new KeyAdapter() {
			public void keyReleased(String id) {
				Connection con = connect();
				try {
					String sql ="SELECT student_no, student_name, gender, address, year_level,contact_num from student_tbl student_name =?";
					PreparedStatement ps=(PreparedStatement) con.prepareStatement(sql);
					ps.setString(1, id);
					ResultSet rs = ps.executeQuery();
					if(rs.next()==false) {
						String student_no =rs.getString(1); 
						String student_name =rs.getString(2);
						String gender =rs.getString(3);
						String address=rs.getString(4);
						String year_level =rs.getString(5);
						String contact_num =rs.getString(6);
					}
					else {
						txtStudentNo.setText("");
						txtStudentName.setText("");
						txtAddress.setText("");
						txtYearlevel.setText("");
						txtContactNo.setText("");	
					}
					
				}catch(Exception ex) {
				System.out.print("Error : " + ex);
			}
		}});
		txtsearch.setBounds(1096, 69, 202, 34);
		contentPane.add(txtsearch);
		txtsearch.setColumns(10);
		
		JLabel lblsearch = new JLabel("SEARCH STUDENT NO.");
		lblsearch.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblsearch.setBounds(922, 73, 188, 22);
		contentPane.add(lblsearch);
		
		JButton btnsearch = new JButton("SEARCH");
		btnsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				viewRecords();
			}
		});
		btnsearch.setBackground(new Color(210, 180, 140));
		btnsearch.setBounds(1313, 72, 107, 28);
		contentPane.add(btnsearch);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane_1.setBounds(316, 129, 1117, 589);
		contentPane.add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_1.setViewportView(scrollPane);
		
		tableView = new JTable();
		tableView.setBackground(Color.LIGHT_GRAY);
		tableView.setFont(new Font("Tahoma", Font.PLAIN, 15));
		tableView.setToolTipText("");
		
		//TABLE EVENT PROCEDURE
		scrollPane.setViewportView(tableView);
		tableView.setColumnSelectionAllowed(true);
		tableView.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				txtStudentNo.setEnabled(false);
				String id = tableView.getValueAt(tableView.getSelectedRow(),0).toString();
				textField(id);
			}
		});
		
		JButton btnupdate = new JButton("UPDATE");
		btnupdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableView.getSelectedRow() >=0) {
					updateRecords(txtStudentNo.getText());
				}
			}
		});
		btnupdate.setBackground(new Color(210, 180, 140));
		btnupdate.setBounds(181, 558, 100, 34);
		contentPane.add(btnupdate);
		
		lblClock = new JLabel("Time: ");
		lblClock.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblClock.setBounds(1218, 45, 202, 22);
		contentPane.add(lblClock);
		
		JLabel lblgender = new JLabel("GENDER :");
		lblgender.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblgender.setBounds(29, 250, 132, 22);
		contentPane.add(lblgender);
		
		txtgender = new JComboBox();
		txtgender.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtgender.setBounds(150, 250, 139, 34);
		txtgender.setModel(new DefaultComboBoxModel(new String[] {"Male","Female","Prefer No to Say"}));
		contentPane.add(txtgender);
		
		JPanel txtregistration = new JPanel();
		txtregistration.setBorder(new TitledBorder(null, "Registration", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		txtregistration.setBounds(11, 114, 295, 372);
		contentPane.add(txtregistration);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "List of Registered Students", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panel.setBounds(307, 112, 1126, 606);
		contentPane.add(panel);
		
		
		
	}
		
	//DATABASE CONNECTION
	static Connection connect() {
		try {
		
			//set the mysql driver
			String myDriver = "com.mysql.cj.jdbc.Driver";
			//connection string
			String url = "jdbc:mysql://localhost:3306/copl_db";
			Class.forName(myDriver);
			return(Connection)DriverManager.getConnection(url,"root","");
		}
		
		catch(Exception e) {
				System.out.print("Cannot connect to the database.");
			}
		return null;
		}
	
	//ADD RECORD METHOD
	private void addRecord() {
		Connection con = connect();
		Calendar date = Calendar.getInstance();
		java.sql.Date datecreated = new java.sql.Date(date.getTime().getTime());
		
		try {
			String sql = "INSERT INTO student_tbl (student_no, student_name, gender, address, year_level,contact_num, date_created) VALUES(?,?,?,?,?,?,NOW())";
			PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
			
			ps.setString(1, txtStudentNo.getText());
			ps.setString(2, txtStudentName.getText());
			ps.setString(3, txtgender.getSelectedItem().toString());
			ps.setString(4, txtAddress.getText());
			ps.setString(5, txtYearlevel.getText());
			ps.setString(6, txtContactNo.getText());
		  //ps.setDate  (6, datecreated);
			ps.execute();
			
			JOptionPane.showMessageDialog(null, "The record is Successfully Added.");
			clearTextField();
		}
		catch(Exception e) {
			System.out.print("Error" + e);
		}
	}
	
		//VIEW RECORD METHOD
		private void viewRecords() {
			Connection con = connect();
			DefaultTableModel mod = new DefaultTableModel();
			mod.addColumn("ID No.");
			mod.addColumn("Student Number");
			mod.addColumn("Student Name");
			mod.addColumn("Gender");
			mod.addColumn("Address");
			mod.addColumn("Year Level");
			mod.addColumn("Contact Number");
			mod.addColumn("Date");
			
			try {
				String sql = "select * from student_tbl";
				Statement st = (Statement) con.createStatement();
				ResultSet rs = st.executeQuery(sql);
				while(rs.next()) {
					mod.addRow(new Object[]{
						rs.getInt("id"),
						rs.getString("student_no"),
						rs.getString("student_name"),
						rs.getString("gender"),
						rs.getString("address"),
						rs.getString("year_level"),
						rs.getString("contact_num"),
						rs.getString("date_created"),
					});
				}
				rs.close();
				rs.close();
				rs.close();
				rs.close();
				rs.close();
				rs.close();
				rs.close();
				
				tableView.setModel(mod);
				//tableView.setAutoResizeMode(0);
				tableView.getColumnModel().getColumn(0).setPreferredWidth(2);
				tableView.getColumnModel().getColumn(1).setPreferredWidth(10);
				tableView.getColumnModel().getColumn(2).setPreferredWidth(10);
				tableView.getColumnModel().getColumn(3).setPreferredWidth(10);
				tableView.getColumnModel().getColumn(4).setPreferredWidth(10);
				tableView.getColumnModel().getColumn(5).setPreferredWidth(10);
				tableView.getColumnModel().getColumn(6).setPreferredWidth(10);
				tableView.getColumnModel().getColumn(7).setPreferredWidth(10);
				
			}catch(Exception ex) {
				System.out.print("Error : " + ex);
			}
		}
		
		//DELETE METHOD
		private void deleteRecord(String id) {
			Connection con = connect();
			try {
				String sql ="DELETE from student_tbl where student_no= ?";
				PreparedStatement ps=(PreparedStatement) con.prepareStatement(sql);
				ps.setString(1, id);
				ps.execute();
				
				ps.close();
				con.close();
				JOptionPane.showMessageDialog(null,"Record deleted from database.");
				clearTextField();
				
			}catch(Exception ex) {
			System.out.print("Error : " + ex);
		}
	}
	//UPDATE METHOD
		private void updateRecords(String id) {
			Connection con = connect();
			try {
				String sql = "UPDATE student_tbl SET student_no=?,student_name =?,gender =?,address =?,year_level=?,contact_num=? where student_no =?";
				PreparedStatement ps=(PreparedStatement) con.prepareStatement(sql);
			
				ps.setString(1, txtStudentNo.getText());
				ps.setString(2, txtStudentName.getText());
				ps.setString(3, txtgender.getSelectedItem().toString());
				ps.setString(4, txtAddress.getText());
				ps.setString(5, txtYearlevel.getText());
				ps.setString(6, txtContactNo.getText());
				ps.setString(7, id);
				ps.execute();
				
				ps.close();
				con.close();
				
				JOptionPane.showMessageDialog(null,"Record successfully updated.");
				clearTextField();
			}catch(Exception ex) {
				System.out.print("Error : " + ex);
			}
		}
		
		//CLICK EVENT FROM TABLE TO INPUT FIELDS
		private void textField(String id) {
			Connection con = connect();
			try {
				String sql = "SELECT * from student_tbl where id = ?";
				PreparedStatement ps=(PreparedStatement) con.prepareStatement(sql);
				ps.setString(1, id);
				ResultSet rs =ps.executeQuery();
				
				while(rs.next()) {
					txtStudentNo.setText(rs.getString("student_no"));
					txtStudentName.setText(rs.getString("student_name"));
					//txtgender.setString(rs.getString("gender").toString());
					txtAddress.setText(rs.getString("address"));
					txtYearlevel.setText(rs.getString("year_level"));
					txtContactNo.setText(rs.getString("contact_num"));
					
				}
				
				
			}catch(Exception ex) {
				System.out.print("Error : " + ex);
			}
		}
		
		//CLEAR METHOD
		private void clearTextField() {
			txtStudentNo.setText("");
			txtStudentName.setText("");
			txtAddress.setText("");
			txtYearlevel.setText("");
			txtContactNo.setText("");	
		}
		
		//TIME AND DATE METHOD
		public void clock() {
			Thread clock = new Thread() {
				public void run() {
					try {
						while(true) {
							Calendar cl = new GregorianCalendar();
							int day = cl.get(Calendar.DAY_OF_MONTH);
							int month = cl.get(Calendar.MONTH);
							int year = cl.get(Calendar.YEAR);
							
							int sec = cl.get(Calendar.SECOND);
							int min =cl.get(Calendar.MINUTE);
							int hr = cl.get(Calendar.HOUR);
							
							lblClock.setText("Time :" +hr + ":" +min+ ":" +sec + " | Date : "+ month + "/" + day + "/" +year);
							sleep(1000);
						}
					}catch(InterruptedException ex) {
						ex.printStackTrace();
					}}};
					clock.start();
				}
}



	
